<?php $host="localhost"; // Host name
$username="crofton_connct"; // Mysql username
$password="wintersS2013"; // Mysql password
$db_name="crofton_cas"; // Database name 

$dbhost = "localhost";
$dbname = "crofton_cas";
$dbuser = "crofton_connct";
$dbpass = "wintersS2013";
?>