<?php
$dbhost = "localhost";
$dbname = "crofton_cas";
$dbuser = "crofton_connct";
$dbpass = "wintersS2013";
?>