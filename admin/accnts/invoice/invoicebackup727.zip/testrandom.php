<?php

for ($i=0;$i<5;$i++) {

  $n = rand(0,100000000);
  
  print_r($n."</br>"); 
  
}
$ic_num = rand(10000000,100000000);
  
  print_r("</br>".$n."</br>"); 



?>