-- 
-- Editor SQL for DB table v_records
-- Created by http://editor.datatables.net/generator
-- 

CREATE TABLE IF NOT EXISTS `v_records` (
	`v_id` int(10) NOT NULL auto_increment,
	`v_did` numeric(9,2),
	`v_uid` numeric(9,2),
	`v_rid` numeric(9,2),
	`txtvin` varchar(255),
	`txtyear` numeric(9,2),
	`txtmake` varchar(255),
	`txtmodel` varchar(255),
	`txtcolor` varchar(255),
	`txtanon` varchar(255),
	`inpvehstock` varchar(255),
	`popdetail` varchar(255),
	`txttrans` varchar(255),
	`txtprice` numeric(9,2),
	`r_time` datetime,
	`v_status` varchar(255),
	`v_substatus` varchar(255),
	PRIMARY KEY( `v_id` )
);