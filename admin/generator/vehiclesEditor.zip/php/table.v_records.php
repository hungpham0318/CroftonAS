<?php

/*
 * Editor server script for DB table v_records
 * Created by http://editor.datatables.net/generator
 */

// DataTables PHP library and database connection
include( "lib/DataTables.php" );

// Alias Editor classes so they are easy to use
use
	DataTables\Editor,
	DataTables\Editor\Field,
	DataTables\Editor\Format,
	DataTables\Editor\Mjoin,
	DataTables\Editor\Upload,
	DataTables\Editor\Validate;

// The following statement can be removed after the first run (i.e. the database
// table has been created). It is a good idea to do this to help improve
// performance.
$db->sql( "CREATE TABLE IF NOT EXISTS `v_records` (
	`v_id` int(10) NOT NULL auto_increment,
	`v_did` numeric(9,2),
	`v_uid` numeric(9,2),
	`v_rid` numeric(9,2),
	`txtvin` varchar(255),
	`txtyear` numeric(9,2),
	`txtmake` varchar(255),
	`txtmodel` varchar(255),
	`txtcolor` varchar(255),
	`txtanon` varchar(255),
	`inpvehstock` varchar(255),
	`popdetail` varchar(255),
	`txttrans` varchar(255),
	`txtprice` numeric(9,2),
	`r_time` datetime,
	`v_status` varchar(255),
	`v_substatus` varchar(255),
	PRIMARY KEY( `v_id` )
);" );

// Build our Editor instance and process the data coming from _POST
Editor::inst( $db, 'v_records', 'v_id' )
	->fields(
		Field::inst( 'v_did' ),
		Field::inst( 'v_uid' ),
		Field::inst( 'v_rid' ),
		Field::inst( 'txtvin' ),
		Field::inst( 'txtyear' ),
		Field::inst( 'txtmake' ),
		Field::inst( 'txtmodel' ),
		Field::inst( 'txtcolor' ),
		Field::inst( 'txtanon' ),
		Field::inst( 'inpvehstock' ),
		Field::inst( 'popdetail' ),
		Field::inst( 'txttrans' ),
		Field::inst( 'txtprice' ),
		Field::inst( 'r_time' )
			->validator( 'Validate::dateFormat', array( 'format'=>'Y-m-d H:i:s' ) )
			->getFormatter( 'Format::datetime', array( 'from'=>'Y-m-d H:i:s', 'to'  =>'Y-m-d H:i:s' ) )
			->setFormatter( 'Format::datetime', array( 'to'  =>'Y-m-d H:i:s', 'from'=>'Y-m-d H:i:s' ) ),
		Field::inst( 'v_status' ),
		Field::inst( 'v_substatus' )
	)
	->process( $_POST )
	->json();
