<div class="tablewrapper">	
<div class="bannerline" style="margin-top:-5em;">
<?php
include 'css/status-key.html';
include 'css/substatus-key.html';
include 'css/status-key.html';
?>
</div>
<table id="example" class="display nowrap" style="width:100%;">
    <thead>
    <tr>
<th></th>
<th>Id</th>
<th>Vin</th>
<th>Year</th>
<th>Make</th>
<th>Model</th>
<th>Color</th>
<th>Mileage</th>
<th>Announcement</th>
<th>Detail</th>
<th>Via</th>

<th>Status</th>
<th>SStatus</th>
<th>Notes</th>
<th>Carfax</th>
<th>Damage</th>
<th>MiscInfo</th>
<th>Lane#</th>
<th>Run#</th>

<th>Stock</th>        

<th>User</th>
<th>Dealer</th> 


  



</tr>
    </thead>
      <tfoot>
        <tr>


<th></th>
<th>Id</th>
<th>Vin</th>
<th>Year</th>
<th>Make</th>
<th>Model</th>
<th>Color</th>
<th>Mileage</th>
<th>Announcement</th>
<th>Detail</th>
<th>Via</th>

<th>Status</th>
<th>SStatus</th>

<th>Notes</th>

<th>Carfax</th>
<th>Damage</th>
<th>MiscInfo</th>
<th>Lane</th>
<th>Run</th>
<th>Rundate</th>
<th>RunOutcome</th>
<th>Stock</th>        

<th>User</th>
<th>Dealer</th> 
       

        </tr>
    </tfoot>
</table>
</div><!--should close tablewrapper-->
</div><!--should close section1-->
</div><!--should close container-->
<script src="https://code.jquery.com/jquery-1.12.3.min.js"></script>
<script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.1.0/js/dataTables.responsive.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.2.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/select/1.2.0/js/dataTables.select.min.js"></script>
<script src="https://cdn.datatables.net/keytable/2.1.1/js/dataTables.keyTable.min.js"></script>
<script src="https://cdn.datatables.net/autofill/2.1.1/js/dataTables.autoFill.min.js"></script>
<script src="/admin/Editor/js/dataTables.editor.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
<script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
<script src="https://cdn.datatables.net/colreorder/1.3.2/js/dataTables.colReorder.min.js"></script>

<script src="https://cdn.datatables.net/scroller/1.4.2/js/dataTables.scroller.min.js"></script>

<script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.1.2/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/fixedcolumns/3.2.1/js/dataTables.fixedColumns.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.2.1/js/buttons.colVis.min.js"></script>
    <script src="https://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
  


<script>
var editor; // use a global for the submit and return data rendering in the examples
 
$(document).ready(function() {
    editor = new $.fn.dataTable.Editor( {
        ajax: "views/reconnew.php",
        table: "#example",
       deferRender:    true,
    //scroller:       true,

        fields: [  
{"label": "mid","name": "master.mid", type:  "readonly", def:   ""},



{"label": "mvin","name": "master.mvin"},
{"label": "myear","name": "master.myear"},
{"label": "mmake","name": "master.mmake"},
{"label": "mmodel","name": "master.mmodel"},
{"label": "mcolor","name": "master.mcolor"},
{"label": "mmileage","name": "master.mmileage"},
{"label": "mannounce","name": "master.mannounce"},
{"label": "mfloor","name": "master.mfloor"},
//{label: 'mrtime',name: 'master.mrtime', type:  'datetime', def:   function () { return new Date(); }},
 {
                label: 'mreqsaledate:',
                name:  'master.mreqsaledate2',
                type:  'datetime'
                },

 
{"label": "mdetail","name": "master.mdetail"},
{"label": "mtransport","name": "master.mtransport"},


{
                type: "select",
               label: "Status:",
                name: "master.mstatus",
               options: [
               "I",
               "A",
               "S",
               "Z",
               "R",
               "X"
                       ]

           }, {
                type:  "select",  
               label: "Substatus:",
                name: "master.msubstatus",
                 options: ["",
        "recon-red",
        "recon-yellow",
        "recon-green",
        "recon-blue",
        "arbit-m",
        "Inv-No",
        "Inv-Sent",
        "Inv-Paid"
    ]},
    
 {"label": "msolddate","name": "master.msolddate"},
{"label": "mnotes","name": "master.mnotes"},
{"label": "msoldprice","name": "master.msoldprice"},
{"label": "mcarfax","name": "master.mcarfax"},
{"label": "mdamage","name": "master.mdamage"},
{"label": "mmiscinfo","name": "master.mmiscinfo"},
{"label": "mlane","name": "master.mlane"},
{"label": "mrun","name": "master.mrun"},
{label: 'mrundate', name: 'master.mrundate', type: 'datetime'},
{"label": "mrunoutcome","name": "master.mrunoutcome"},
{"label": "mstock","name": "master.mstock"},
{"label": "Auction",
"name": "master.maid",
type: "select",
placeholder:"Select Auction"},


{"label": "User",
"name": "master.muid",
type: "select",
placeholder:"Select User"},

{"label": "Dealership",
"name": "master.mdid",
type: "select",
placeholder:"Select Dealer"},

{"label": "minvid","name": "master.minvid"},
{"label": "marchive","name": "master.marchive"},
//{"label": "mreconview","name": "master.mreconview"},
//{
 //               label:     "On Recon?",
//                name:      "master.mreconview",
//                type:      "checkbox",
//                separator: "|",
//                options:   [
//                    { label: '', value: 1 }
//                ]
//            }, 
//{"label": "mrid","name": "master.mrid"},
//{"label": "mvid","name": "master.mvid"},
//{"label": "mreqsaledate2","name": "master.mreqsaledate2"},

        ]
 });
 
// $('#example').on( 'click', 'tbody td, tbody span.dtr-data', function (e) {
        // Ignore the Responsive control and checkbox columns
//        if ( $(this).hasClass( 'control' ) || $(this).hasClass('select-checkbox') ) {
//            return;
//        }
 
 //       //editor.inline( this );
//  } );
//  $('#example tfoot th').each( function () {
//        var title = $(this).text();
//        $(this).html( '<input type="text" placeholder=" '+title+'" />' );
//    } );
// Activate an inline edit on click of a table cell
    // or a DataTables Responsive data cell
    
 
    var table = $('#example').DataTable( {
   "scrollY": 500,
   // responsive: true,
    scrollX: "true",    
    dom: "Bfrtlip",
    colReorder: true,
  
       
 	iDisplayLength: "500",
	lengthMenu: [[10, 100, 500, -1], [10, 100, 500, "All"]], 
  	ajax: "views/reconnew.php",
        columns: [
// {   // Responsive control column
       //         data: null,
       //         defaultContent: '',
       //         className: 'control',
       //         orderable: false
       //     },
 {   // Checkbox select column
                data: null,
                defaultContent: '',
                className: 'select-checkbox',
                orderable: false
            },
{ data: "master.mid" },
{ data: "master.mvin" },
{ data: "master.myear" },
{ data: "master.mmake" },
{ data: "master.mmodel" },
{ data: "master.mcolor" },
{ data: "master.mmileage" },
{ data: "master.mannounce" },
{ data: "master.mdetail" },
{ data: "master.mtransport" },
{ data: "master.mfloor" },
//{ data: "master.mrtime" },
{ data: "master.mreqsaledate2" },
{ data: "master.mstatus" },
{ data: "master.msubstatus" },
{ data: "master.msolddate" },
{ data: "master.mnotes" },
{ data: "master.msoldprice" },
{ data: "master.mcarfax" },
{ data: "master.mdamage" },
{ data: "master.mmiscinfo" },
{ data: "master.mlane" },
{ data: "master.mrun" },
{ data: "master.mrundate" },
{ data: "master.mrunoutcome" },
{ data: "master.mstock" },
{ data: "auctions.a_name" },
{ data: "users.uname" },
{ data: "dealers.dname" },
{ data: "master.minvid" },
{ data: "master.marchive" },
//{ data: "master.mreconview" },
{data:"master.mreconview",
        render: function ( data, type, row ) {
                    if ( type === 'display' ) {
                        return '<input type="checkbox" class="editor-active">';
                    }
                    return data;
                },
                className: "dt-body-center"
            }
        ],
        select: {
            style: 'os',
            selector: 'td:not(:last-child)' // no row selection on last column
        },
	 
        autoFill: {
            columns: ':not(:first-child)',
            editor:  editor
        },
        keys: {
            columns: ':not(:first-child)',
            editor:  editor
        },
        select: {
            style:    'os',
            selector: 'td:nth-child(1)',
            blurable: true
        },
         
        buttons: [

            { extend: "create", editor: editor },
            { extend: "edit",   editor: editor },
{extend: 'pdfHtml5', orientation: 'landscape', pageSize: 'A1'},
           // { extend: "remove", editor: editor },
      'colvis',
      'excelHtml5',
            'csvHtml5',
            'pdfHtml5',
            
        ],
  
           

"rowCallback": function ( row, data ) { 

$('td', row).attr('nowrap','nowrap');
$('td', row).css('text-transform', 'Uppercase','white-space','nowrap','font-family','monospace');
   if ( data.master.msubstatus == "recon-green" ){ $('td', row).css('background-color', '#00FF66');}
   else if ( data.master.msubstatus == "recon-red" ){ $('td', row).css('background-color', '#FCA38B');}
   else if ( data.master.msubstatus == "recon-blue" ){ $('td', row).css('background-color', '#00CCFF');}
   else if ( data.master.msubstatus == "recon-yellow" ){ $('td', row).css('background-color', '#FFFF66');}
   else if ( data.master.msubstatus == "arbit-m" ){ $('td', row).css('background-color', '#99FF66');}
   else if ( data.master.msubstatus == "arbit-z" ){ $('td', row).css('background-color', '#CCFF66');}
   else if ( data.master.msubstatus == "Inv-No" ){ $('td', row).css('background-color', 'Orange');}
  else if ( data.master.msubstatus == "Inv-Sent" ){ $('td', row).css('background-color', '#ffffff');}
   else if ( data.master.msubstatus == "Inv-Paid" ){ $('td', row).css('background-color', 'Transparent');}
$('input.editor-active', row).prop( 'checked', data.master.mreconview == 1 );
}
           
       
     });
 
 
// Disable KeyTable while the main editing form is open
 editor
        .on( 'open', function ( e, mode, action ) {
            if ( mode === 'main' ) {
                table.keys.disable();
            }
        } )
        .on( 'close', function () {
            table.keys.enable();
        } );
        table.order.fixed( {
           pre: [ 1, 'desc' ]
} );

     //table.columns().every( function () {
       // var that = this;
 
       // $( 'input', this.footer() ).on( 'keyup change', function () {
          //  if ( that.search() !== this.value ) {
            //    that
                 //   .search( this.value )
                 //   .draw();
         //   }
       // } );
   // } ); 
 $('#example').on( 'change', 'input.editor-active', function () {
        editor
            .edit( $(this).closest('tr'), false )
            .set( 'master.mreconview', $(this).prop( 'checked' ) ? 1 : 0 )
            .submit();
    } );
  	 
  
} );
</script>
</div> close table wrapper from html.html file